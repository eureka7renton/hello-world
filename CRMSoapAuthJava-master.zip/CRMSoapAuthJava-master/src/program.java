import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import dto.DBA001Dto;
import dto.DBA004Dto;
import dto.DBA007Dto;

public class program {

	private static Logger logger = Logger.getLogger(program.class);
	private CrmAuthenticationHeader authHeader;//認証ヘッダ
	private String url = "https://meitec-dev.crm7.dynamics.com/";

	public static void main(String[] args) throws Exception {
		program app = new program();
		app.run();
	}

	public void run() throws Exception {

			//Step1.Dynamics365認証
			setAuthHeader();

			//Step2.Dynamics365->MyCareer:新規申告登録
			logger.info("-----------新規申告登録：開始-----------");
			createNewRcd();
			logger.info("-----------新規申告登録：完了-----------");

			//Step3.MyCareer->Dynamics365:申告反映
			logger.info("-----------MyCareer=>Dynamics365申告反映開始-----------");
			updateDynamics();
			logger.info("-----------MyCareer=>Dynamics365申告反映完了-----------");

			//Step4.Dynamics365->MyCareer:面談反映
			logger.info("-----------Dynamics365=>MyCareer面談反映開始-----------");
			updateMyCareer();
			logger.info("-----------Dynamics365=>MyCareer面談反映完了-----------");


	}

	private void setAuthHeader() throws Exception{

		try {
			//1-1.連携バッチ用のアカウント情報
			String username ="dynamics-admin@meitecgrp.onmicrosoft.com";
			String password = "dyna-Adm@";
			//1-2.認証処理(Token取得してから、認証ヘッダを生成する)
			CrmAuth auth = new CrmAuth();
			this.authHeader = auth.GetHeaderOnline(username,password, this.url);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			String message = getStackTrace(e);
			logger.error(message);
			throw new RuntimeException(e);
		}
	}

	private void createNewRcd(){

		try {
			//2-1.Dynamics365より新規依頼レコードを取得する
			List<DBA001Dto> crtList = CrmGetCrtRcd();
			//2-2.MyCareerにレコードを登録する
			for(DBA001Dto dto:crtList){
				if( MyCareerCrtRcd(dto) == 1 ){
					//2-3.Dynamics365側で作成済を更新する
					dto.setNew_updated(true);
					CrmIsUpdate(dto.getNew_my_careerid(),dto.isNew_updated());
					logger.info(dto.getNew_apply_no());
				}
			}
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			String message = getStackTrace(e);
			logger.error(message);
			throw new RuntimeException(e);
		}
	}

	private void updateDynamics(){

		try {
			//3-1.MyCareerより連携用のレコードを抽出する
			List<DBA004Dto> updList = MyCareerGetRcd();
			//3-2.抽出されたレコードをDynamics365側へ連携する
			for(DBA004Dto dto:updList){
				//TBD更新結果を受信する
				CrmUpdate(dto);
				//3-3.連携結果を受信し、MyCareer側で連携済を更新する
				dto.setIS_UPDATED("1");
				MyCareerIsUpdate(dto);
				logger.info(dto.getCRM_GUID());
			}
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			String message = getStackTrace(e);
			logger.error(message);
			throw new RuntimeException(e);
		}
	}

	private void updateMyCareer() throws IOException, SAXException, ParserConfigurationException, TransformerException{

		try {
			//4-1.Dynamics365より連携用のレコードを抽出する
			List<DBA007Dto> updList = CrmGetUpdRcd();
			//4-2.抽出されたレコードをMyCareer側へ連携する
			for(DBA007Dto dto:updList){
				MyCareerUpdate(dto);
				//4-3.連携結果を取得し、Dynamics365側で連携済を更新する
				dto.setNew_updated(true);
				CrmIsUpdate(dto.getNew_my_careerid(),dto.isNew_updated());
				logger.info(dto.getNew_my_careerid());
			}
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			String message = getStackTrace(e);
			logger.error(message);
			throw new RuntimeException(e);
		}
	}

	private void temp(){

//		CrmAuth auth = new CrmAuth();
//
//		// CRM Online ログインurl、ユーザID、PW
//		String url = "https://meitec-dev.crm7.dynamics.com/";
//		String username ="dynamics-admin@meitecgrp.onmicrosoft.com";
//		String password = "dyna-Adm@";

		//CrmAuthenticationHeader authHeader = auth.GetHeaderOnline(username,password, url);
		// End CRM Online

		//String id = CrmWhoAmI(authHeader, url);
		//if (id == null){
		//	return;
		//}

		//String name = CrmGetUserName(authHeader, id, url);
		//System.out.println(name);
		//String testName = "Wang";

		//フィルター条件で、複数レコードを取得する


		//CrmCreateTest(authHeader,testName,url);
		// CrmUpdateTest(authHeader,testName,url);
		//GetMultiRecords(authHeader,url);

		// NewTestParent testObj = new NewTestParent();
		// SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		// testObj.new_emp_name = "Java";
		// testObj.new_sex = false;
		// testObj.new_contact_start_date = sdf.parse("19871215");
		// testObj.new_select_cutomized = new CrmOptionSet("100000001");
		// testObj.new_emp_age = 29;
		// testObj.new_float = 2.71;
		// testObj.new_multi = "あいうえお\r\nかきくけこ";
		// testObj.new_money = new CrmMoney(5000);
		// testObj.new_lookup = new CrmReference("new_mago","a1","a2241c5e-29bb-e511-80f7-fc15b428ddc0");
		// CrmCreateTest2(authHeader,testObj,url);
	}

	public static void CrmCreateTest2(CrmAuthenticationHeader authHeader,NewTestParent ent,String url) throws IOException,SAXException,ParserConfigurationException{

		StringBuilder xml = CreateXml(ent);

		Document xDoc = CrmExecuteSoap.ExecuteSoapRequest(authHeader,xml.toString(),url);
		if (xDoc == null) {
			return;
		}
	}

	public static StringBuilder CreateXml(Object ent){

		StringBuilder xml = new StringBuilder();
		xml.append(CrmXmlConst.creatHead);
		Field[] field = ent.getClass().getDeclaredFields();
		for (int i = 0;i<field.length ;i++ ) {
			xml.append(fieldXml(ent,field[i]));
		}
		xml.append(CrmXmlConst.creatTail);

		return xml;
	}

	public static StringBuilder fieldXml(Object entObj,Field entField){
		try {
			StringBuilder xml = new StringBuilder();
			String fieldType = entField.getGenericType().toString();
			String fieldTypeName = fieldType.lastIndexOf(".") == -1 ? fieldType.substring(fieldType.lastIndexOf(" ")+1): fieldType.substring(fieldType.lastIndexOf(".")+1);
			//String fieldTypeName = fieldType.lastIndexOf(".") == -1 ? fieldType.substring(fieldType.lastIndexOf(" ")+1): fieldType.substring(fieldType.lastIndexOf(".")+1);
			String fieldName = entField.getName();

			switch(fieldTypeName){
				case "String":
					xml.append("<a:KeyValuePairOfstringanyType>");
					xml.append("<b:key>" + fieldName + "</b:key>");
					xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ entField.get(entObj) +"</b:value>");
					xml.append("</a:KeyValuePairOfstringanyType>");
					break;
				case "Boolean":
					xml.append("<a:KeyValuePairOfstringanyType>");
					xml.append("<b:key>" + fieldName + "</b:key>");
					xml.append("<b:value i:type=\"c:boolean\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ entField.get(entObj) +"</b:value>");
					xml.append("</a:KeyValuePairOfstringanyType>");
					break;
				case "Date":
					xml.append("<a:KeyValuePairOfstringanyType>");
					xml.append("<b:key>" + fieldName + "</b:key>");
					xml.append("<b:value i:type=\"c:dateTime\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ new SimpleDateFormat("yyyy-MM-dd").format(entField.get(entObj)) +"</b:value>");
					xml.append("</a:KeyValuePairOfstringanyType>");
					break;
				case "int":
					xml.append("<a:KeyValuePairOfstringanyType>");
					xml.append("<b:key>" + fieldName + "</b:key>");
					xml.append("<b:value i:type=\"c:int\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ entField.get(entObj) +"</b:value>");
					xml.append("</a:KeyValuePairOfstringanyType>");
					break;
				case "double":
					xml.append("<a:KeyValuePairOfstringanyType>");
					xml.append("<b:key>" + fieldName + "</b:key>");
					xml.append("<b:value i:type=\"c:double\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ entField.get(entObj) +"</b:value>");
					xml.append("</a:KeyValuePairOfstringanyType>");
					break;
				case "CrmOptionSet":
					xml.append("<a:KeyValuePairOfstringanyType>");
					xml.append("<b:key>" + fieldName + "</b:key>");
					xml.append("<b:value i:type=\"a:OptionSetValue\" ><a:Value>"+ ((CrmOptionSet)entField.get(entObj)).getValue() + "</a:Value></b:value>");
					xml.append("</a:KeyValuePairOfstringanyType>");
					break;
				case "CrmMoney":
					xml.append("<a:KeyValuePairOfstringanyType>");
					xml.append("<b:key>"+fieldName+"</b:key>");
					xml.append("<b:value i:type=\"a:Money\" ><a:Value>"+ ((CrmMoney)entField.get(entObj)).getValue() +"</a:Value></b:value>");
					xml.append("</a:KeyValuePairOfstringanyType>");
					break;
				case "CrmReference":
					xml.append("<a:KeyValuePairOfstringanyType>");
					xml.append("<b:key>"+fieldName+"</b:key>");
					xml.append("<b:value i:type=\"a:EntityReference\">");
			        xml.append("<a:Id>"+((CrmReference)entField.get(entObj)).getGuid()+"</a:Id>");
			        xml.append("<a:KeyAttributes xmlns:c=\"http://schemas.microsoft.com/xrm/7.1/Contracts\" />");
			        xml.append("<a:LogicalName>"+((CrmReference)entField.get(entObj)).getLogicalName()+"</a:LogicalName>");
			        xml.append("<a:Name i:nil=\"true\" />");
			        xml.append("<a:RowVersion i:nil=\"true\" />");
			        xml.append("</b:value>");
					xml.append("</a:KeyValuePairOfstringanyType>");
					break;
				default:
					break;
			}

			return xml;
		} catch (IllegalArgumentException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return null;
	}

	//CRMにて連携済更新
	public void CrmIsUpdate(String guid,boolean result) throws IOException,SAXException,ParserConfigurationException{

		StringBuilder xml = new StringBuilder();
		xml.append("<s:Body>");
		xml.append("<Execute xmlns=\"http://schemas.microsoft.com/xrm/2011/Contracts/Services\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">");
		xml.append("<request i:type=\"a:UpdateRequest\" xmlns:a=\"http://schemas.microsoft.com/xrm/2011/Contracts\">");
		xml.append("<a:Parameters xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\">");
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>Target</b:key>");
		xml.append("<b:value i:type=\"a:Entity\">");
		xml.append("<a:Attributes>");

		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_updated</b:key>");
		xml.append("<b:value i:type=\"c:boolean\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ result +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		xml.append("</a:Attributes>");
		xml.append("<a:EntityState i:nil=\"true\" />");
		xml.append("<a:FormattedValues />");
		xml.append("<a:Id>" + guid + "</a:Id>");
		xml.append("<a:KeyAttributes xmlns:c=\"http://schemas.microsoft.com/xrm/7.1/Contracts\" />");
		xml.append("<a:LogicalName>new_my_career</a:LogicalName>");
		xml.append("<a:RelatedEntities />");
		xml.append("<a:RowVersion i:nil=\"true\" />");
		xml.append("</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");
		xml.append("</a:Parameters>");
		xml.append("<a:RequestId i:nil=\"true\" />");
		xml.append("<a:RequestName>Update</a:RequestName>");
		xml.append("</request>");
		xml.append("</Execute>");
		xml.append("</s:Body>");

		Document xDoc = CrmExecuteSoap.ExecuteSoapRequest(this.authHeader,xml.toString(),this.url);
		if (xDoc == null) {
			return;
		}
	}

	//MyCareer->CRM:データ連携
	public void CrmUpdate(DBA004Dto dto) throws IOException,SAXException,ParserConfigurationException{

		StringBuilder xml = new StringBuilder();
		xml.append("<s:Body>");
		xml.append("<Execute xmlns=\"http://schemas.microsoft.com/xrm/2011/Contracts/Services\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">");
		xml.append("<request i:type=\"a:UpdateRequest\" xmlns:a=\"http://schemas.microsoft.com/xrm/2011/Contracts\">");
		xml.append("<a:Parameters xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\">");
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>Target</b:key>");
		xml.append("<b:value i:type=\"a:Entity\">");
		xml.append("<a:Attributes>");

		//フェーズ
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_phase_code</b:key>");
		xml.append("<b:value i:type=\"a:OptionSetValue\" ><a:Value>"+ dto.getPHASE_CODE() +"</a:Value></b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//ステータス
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_status_code</b:key>");
		xml.append("<b:value i:type=\"a:OptionSetValue\" ><a:Value>"+ dto.getSTATUS_CODE() +"</a:Value></b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_報告日
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_report_date</b:key>");
		xml.append("<b:value i:type=\"c:dateTime\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_RPT_DATE() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_業務担当フェーズ
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_work_phase</b:key>");
		xml.append("<b:value i:type=\"a:OptionSetValue\" ><a:Value>"+ dto.getSHIN_WORK_PHASE() +"</a:Value></b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_業務概要
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_work_knowledge</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_WORK_KNOWLEDGE() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_TCDの更新
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_tcd_update</b:key>");
		xml.append("<b:value i:type=\"a:OptionSetValue\" ><a:Value>"+ dto.getSHIN_TCD_UPDATE() +"</a:Value></b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_自分の強み
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_self_strength</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_SELF_STRENGTH() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_製品
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_product</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_PRODUCT() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_業務内容
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_work_describe</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_WORK_DESCRIBE() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_市場価値
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_market_value</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_MARKET_VALUE() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_中長期Vision
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_vision</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_VISION() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_目標課題
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_goal_challenge</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_GOAL_CHALLENGE() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_希望地域
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_hope_area</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_HOPE_AREA() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//申告_特記事項
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_other_info</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getSHIN_OTHER_INFO() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

		//評価_報告日
		if(dto.getHYOU_RPT_DATE() != null && !("").equals(dto.getHYOU_RPT_DATE())){
			xml.append("<a:KeyValuePairOfstringanyType>");
			xml.append("<b:key>new_self_evaluation_dat</b:key>");
			xml.append("<b:value i:type=\"c:dateTime\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getHYOU_RPT_DATE() +"</b:value>");
			xml.append("</a:KeyValuePairOfstringanyType>");
		}

		//評価_自己評価_取組み
		xml.append("<a:KeyValuePairOfstringanyType>");
		xml.append("<b:key>new_self_evaluation_effort</b:key>");
		xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.getHYOU_SELF_EVALUATION_EFFORT() +"</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");

//		--------------------------------------------------------------------
		// xml.append("<a:KeyValuePairOfstringanyType>");
		// xml.append("<b:key>new_emp_name</b:key>");
		// xml.append("<b:value i:type=\"c:string\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ fieldValue +"</b:value>");
		// xml.append("</a:KeyValuePairOfstringanyType>");

//		xml.append("<a:KeyValuePairOfstringanyType>");
//		xml.append("<b:key>new_emp_age</b:key>");
//		xml.append("<b:value i:type=\"c:int\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ 18 +"</b:value>");
//		xml.append("</a:KeyValuePairOfstringanyType>");

//		xml.append("<a:KeyValuePairOfstringanyType>");
//		xml.append("<b:key>new_updated</b:key>");
//		xml.append("<b:value i:type=\"c:boolean\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ dto.isNew_updated() +"</b:value>");
//		xml.append("</a:KeyValuePairOfstringanyType>");

		// xml.append("<a:KeyValuePairOfstringanyType>");
		// xml.append("<b:key>new_contact_start_date</b:key>");
		// xml.append("<b:value i:type=\"c:dateTime\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ "1987-12-12T00:00:00" +"</b:value>");
		// xml.append("</a:KeyValuePairOfstringanyType>");

		// xml.append("<a:KeyValuePairOfstringanyType>");
		// xml.append("<b:key>new_select_cutomized</b:key>");
		// xml.append("<b:value i:type=\"a:OptionSetValue\" ><a:Value>"+ "100000001" +"</a:Value></b:value>");
		// xml.append("</a:KeyValuePairOfstringanyType>");

		// xml.append("<a:KeyValuePairOfstringanyType>");
		// xml.append("<b:key>new_float</b:key>");
		// xml.append("<b:value i:type=\"c:double\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\">"+ "3.14" +"</b:value>");
		// xml.append("</a:KeyValuePairOfstringanyType>");

		// xml.append("<a:KeyValuePairOfstringanyType>");
		// xml.append("<b:key>new_money</b:key>");
		// xml.append("<b:value i:type=\"a:Money\" ><a:Value>"+ "7000" +"</a:Value></b:value>");
		// xml.append("</a:KeyValuePairOfstringanyType>");

		// xml.append("<a:KeyValuePairOfstringanyType>");
		// xml.append("<b:key>new_lookup</b:key>");
		// xml.append("<b:value i:type=\"a:EntityReference\">");
		// xml.append("<a:Id>a2241c5e-29bb-e511-80f7-fc15b428ddc0</a:Id>");
		// xml.append("<a:KeyAttributes xmlns:c=\"http://schemas.microsoft.com/xrm/7.1/Contracts\" />");
		// xml.append("<a:LogicalName>new_mago</a:LogicalName>");
		// xml.append("<a:Name i:nil=\"true\" />");
		// xml.append("<a:RowVersion i:nil=\"true\" />");
		// xml.append("</b:value>");
		// xml.append("</a:KeyValuePairOfstringanyType>");
//		--------------------------------------------------------------------


		xml.append("</a:Attributes>");
		xml.append("<a:EntityState i:nil=\"true\" />");
		xml.append("<a:FormattedValues />");
		xml.append("<a:Id>" + dto.getCRM_GUID() + "</a:Id>");
		xml.append("<a:KeyAttributes xmlns:c=\"http://schemas.microsoft.com/xrm/7.1/Contracts\" />");
		xml.append("<a:LogicalName>new_my_career</a:LogicalName>");
		xml.append("<a:RelatedEntities />");
		xml.append("<a:RowVersion i:nil=\"true\" />");
		xml.append("</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");
		xml.append("</a:Parameters>");
		xml.append("<a:RequestId i:nil=\"true\" />");
		xml.append("<a:RequestName>Update</a:RequestName>");
		xml.append("</request>");
		xml.append("</Execute>");
		xml.append("</s:Body>");

		Document xDoc = CrmExecuteSoap.ExecuteSoapRequest(this.authHeader,xml.toString(),this.url);
		if (xDoc == null) {
			return;
		}
	}


	//dynamics365から作成レコードを取得する
	private List<DBA001Dto> CrmGetCrtRcd() throws IOException,SAXException,ParserConfigurationException, TransformerException{

		StringBuilder xml = new StringBuilder();
		xml.append("<s:Body>");
		xml.append("<Execute xmlns=\"http://schemas.microsoft.com/xrm/2011/Contracts/Services\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">");
		xml.append("<request i:type=\"a:RetrieveMultipleRequest\" xmlns:a=\"http://schemas.microsoft.com/xrm/2011/Contracts\">");
		xml.append("<a:Parameters xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\">");
		xml.append("<a:KeyValuePairOfstringanyType>");

		xml.append("<b:key>Query</b:key>");
		xml.append("<b:value i:type=\"a:QueryExpression\">");

		//取得フィールド
		xml.append("<a:ColumnSet>");
		xml.append("<a:AllColumns>false</a:AllColumns>");
		xml.append("<a:Columns xmlns:c=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">");
			//フィールド1
			xml.append("<c:string>new_apply_no</c:string>");
			//フィールド2
			xml.append("<c:string>new_shaincd</c:string>");
			//フィールド3
			xml.append("<c:string>new_my_careerid</c:string>");
		xml.append("</a:Columns>");
		xml.append("</a:ColumnSet>");

		//抽出条件
		xml.append("<a:Criteria>");
		xml.append("<a:Conditions>");
			//抽出条件1
			xml.append("<a:ConditionExpression>");
			xml.append("<a:AttributeName>new_phase_code</a:AttributeName>");
			xml.append("<a:Operator>Equal</a:Operator>");
			xml.append("<a:Values xmlns:c=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">");
			xml.append("<c:anyType i:type=\"d:string\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">1</c:anyType>");
			xml.append("</a:Values>");
			xml.append("<a:EntityName i:nil=\"true\" />");
			xml.append("</a:ConditionExpression>");
			//抽出条件2
			xml.append("<a:ConditionExpression>");
			xml.append("<a:AttributeName>new_updated</a:AttributeName>");
			xml.append("<a:Operator>Equal</a:Operator>");
			xml.append("<a:Values xmlns:c=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">");
			xml.append("<c:anyType i:type=\"d:string\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">0</c:anyType>");
			xml.append("</a:Values>");
			xml.append("<a:EntityName i:nil=\"true\" />");
			xml.append("</a:ConditionExpression>");
		xml.append("</a:Conditions>");
		xml.append("<a:FilterOperator>And</a:FilterOperator>");
		xml.append("<a:Filters />");
		xml.append("</a:Criteria>");

		//対象エンティティ
		xml.append("<a:Distinct>false</a:Distinct>");
		xml.append("<a:EntityName>new_my_career</a:EntityName>");
		xml.append("<a:LinkEntities />");
		xml.append("<a:Orders />");
		xml.append("<a:PageInfo>");
		xml.append("<a:Count>0</a:Count>");
		xml.append("<a:PageNumber>0</a:PageNumber>");
		xml.append("<a:PagingCookie i:nil=\"true\" />");
		xml.append("<a:ReturnTotalRecordCount>false</a:ReturnTotalRecordCount>");
		xml.append("</a:PageInfo>");
		xml.append("<a:NoLock>false</a:NoLock>");

		xml.append("</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");
		xml.append("</a:Parameters>");
		xml.append("<a:RequestId i:nil=\"true\" />");
		xml.append("<a:RequestName>RetrieveMultiple</a:RequestName>");
		xml.append("</request>");
		xml.append("</Execute>");
		xml.append("</s:Body>");


		//--------response--------
		Document xDoc = CrmExecuteSoap.ExecuteSoapRequest(this.authHeader,xml.toString(), this.url);
		if (xDoc != null){
			DOMSource domSource = new DOMSource(xDoc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.transform(domSource, result);
			//String test = writer.toString();
		}

		//操作dto
		List<DBA001Dto> list = new ArrayList<DBA001Dto>();

		NodeList nodes = xDoc.getElementsByTagName("b:Entity");
		for(int i = 0; i<nodes.getLength(); i++){
			DBA001Dto dto = new DBA001Dto();
			NodeList attributes = nodes.item(i).getFirstChild().getChildNodes();
			for(int j = 0; j<attributes.getLength();j++){
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_apply_no")) {
					dto.setNew_apply_no(attributes.item(j).getLastChild().getTextContent());
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_shaincd")) {
					dto.setNew_shaindcd(attributes.item(j).getLastChild().getTextContent());
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_my_careerid")) {
					dto.setNew_my_careerid(attributes.item(j).getLastChild().getTextContent());
				}
			}
			list.add(dto);
		}

		return list;
	}

	//dynamics 365から更新レコードを取得する
	private List<DBA007Dto> CrmGetUpdRcd() throws IOException,SAXException,ParserConfigurationException, TransformerException{

		StringBuilder xml = new StringBuilder();
		xml.append("<s:Body>");
		xml.append("<Execute xmlns=\"http://schemas.microsoft.com/xrm/2011/Contracts/Services\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">");
		xml.append("<request i:type=\"a:RetrieveMultipleRequest\" xmlns:a=\"http://schemas.microsoft.com/xrm/2011/Contracts\">");
		xml.append("<a:Parameters xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\">");
		xml.append("<a:KeyValuePairOfstringanyType>");

		xml.append("<b:key>Query</b:key>");
		xml.append("<b:value i:type=\"a:QueryExpression\">");

		//取得フィールド
		xml.append("<a:ColumnSet>");
		xml.append("<a:AllColumns>false</a:AllColumns>");
		xml.append("<a:Columns xmlns:c=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">");
			xml.append("<c:string>new_my_careerid</c:string>");//レコードのGuid
			xml.append("<c:string>new_phase_code</c:string>");//フェーズ
			xml.append("<c:string>new_status_code</c:string>");//ステータス
			xml.append("<c:string>new_work_phase_a</c:string>");//申告後_業務担当フェーズ
			xml.append("<c:string>new_work_knowledge_a</c:string>");//申告後_業務概要
			xml.append("<c:string>new_tcd_update_a</c:string>");//申告後_自分の強み
			xml.append("<c:string>new_self_strength_a</c:string>");//申告後_TCDの更新
			xml.append("<c:string>new_product_a</c:string>");//申告後_製品
			xml.append("<c:string>new_work_describe_a</c:string>");//申告後_業務内容
			xml.append("<c:string>new_market_value_a</c:string>");//申告後_市場価値
			xml.append("<c:string>new_vision_a</c:string>");//申告後_中長期Vision
			xml.append("<c:string>new_goal_challenge_a</c:string>");//申告後_目標課題
			xml.append("<c:string>new_hope_area_a</c:string>");//申告後_希望地域
			xml.append("<c:string>new_other_info_a</c:string>");//申告後_特記事項
			xml.append("<c:string>new_interview_date</c:string>");//目標_面談日
			xml.append("<c:string>new_interviewer1</c:string>");//目標_面談者
			xml.append("<c:string>new_careerup_content</c:string>");//目標_キャリアアップ計画内容
			xml.append("<c:string>new_careerup_select</c:string>");//目標_キャリアアップ計画選択
			xml.append("<c:string>new_rt_2</c:string>");//目標_RT対象者
			xml.append("<c:string>new_rt_plan</c:string>");//目標_RT実施時期
			xml.append("<c:string>new_rt_select</c:string>");//目標_RT区分
			xml.append("<c:string>new_effort_plan</c:string>");//目標_キャリアアップの取組み
			xml.append("<c:string>new_effort_other_plan</c:string>");//目標_他評価の目標設定
			xml.append("<c:string>new_effort_status</c:string>");//目標_ステータス
			xml.append("<c:string>new_next_date</c:string>");//目標_次回実施予定日
			xml.append("<c:string>new_next_follow</c:string>");//目標_次回フォロー内容
			xml.append("<c:string>new_interviewer2</c:string>");//評価_面談者
			xml.append("<c:string>new_ec_evaluation_date</c:string>");//評価_EC長評価_日付
			xml.append("<c:string>new_ec_evaluation_opt</c:string>");//評価_EC長評価_選択
			xml.append("<c:string>new_ec_evaluation_reason</c:string>");//評価_EC長評価_理由
			xml.append("<c:string>new_ec_evaluation_other_opt</c:string>");//評価_EC長評価_他項目選択
			xml.append("<c:string>new_ec_evaluation_other_reason</c:string>");//評価_EC長評価_他項目理由
			xml.append("<c:string>new_taika_select</c:string>");//処遇_対価要件_選択
			xml.append("<c:string>new_taika_content</c:string>");//処遇_対価要件_内容
			xml.append("<c:string>new_check_independence</c:string>");//処遇_自立
			xml.append("<c:string>new_independence_1</c:string>");//処遇_自立_予定1
			xml.append("<c:string>new_independence_2</c:string>");//処遇_自立_予定2
			xml.append("<c:string>new_independence_3</c:string>");//処遇_自立_予定3
			xml.append("<c:string>new_independence_4</c:string>");//処遇_自立_予定4
			xml.append("<c:string>new_independence_5</c:string>");//処遇_自立_予定5
			xml.append("<c:string>new_independence_6</c:string>");//処遇_自立_予定6
			xml.append("<c:string>new_check_support</c:string>");//処遇_支え合い
			xml.append("<c:string>new_support_1</c:string>");//処遇_支え合い_予定1
			xml.append("<c:string>new_support_2</c:string>");//処遇_支え合い_予定2
			xml.append("<c:string>new_support_3</c:string>");//処遇_支え合い_予定3
			xml.append("<c:string>new_support_4</c:string>");//処遇_支え合い_予定4
			xml.append("<c:string>new_support_5</c:string>");//処遇_支え合い_予定5
			xml.append("<c:string>new_support_6</c:string>");//処遇_支え合い_予定6
			xml.append("<c:string>new_web_check</c:string>");//処遇_人間力基礎WEB研修
			xml.append("<c:string>new_human_check</c:string>");//処遇_社内人間力研修
			xml.append("<c:string>new_salary_remark</c:string>");//処遇_備考

		xml.append("</a:Columns>");
		xml.append("</a:ColumnSet>");

		//抽出条件
		xml.append("<a:Criteria>");
		xml.append("<a:Conditions>");
			//抽出条件1
			xml.append("<a:ConditionExpression>");
			xml.append("<a:AttributeName>new_phase_code</a:AttributeName>");
			xml.append("<a:Operator>In</a:Operator>");
			xml.append("<a:Values xmlns:c=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">");
			xml.append("<c:anyType i:type=\"d:string\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">2</c:anyType>");
			xml.append("<c:anyType i:type=\"d:string\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">3</c:anyType>");
			xml.append("<c:anyType i:type=\"d:string\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">4</c:anyType>");
			xml.append("</a:Values>");
			xml.append("<a:EntityName i:nil=\"true\" />");
			xml.append("</a:ConditionExpression>");
			//抽出条件2
			xml.append("<a:ConditionExpression>");
			xml.append("<a:AttributeName>new_updated</a:AttributeName>");
			xml.append("<a:Operator>Equal</a:Operator>");
			xml.append("<a:Values xmlns:c=\"http://schemas.microsoft.com/2003/10/Serialization/Arrays\">");
			xml.append("<c:anyType i:type=\"d:string\" xmlns:d=\"http://www.w3.org/2001/XMLSchema\">0</c:anyType>");
			xml.append("</a:Values>");
			xml.append("<a:EntityName i:nil=\"true\" />");
			xml.append("</a:ConditionExpression>");
		xml.append("</a:Conditions>");
		xml.append("<a:FilterOperator>And</a:FilterOperator>");
		xml.append("<a:Filters />");
		xml.append("</a:Criteria>");

		//対象エンティティ
		xml.append("<a:Distinct>false</a:Distinct>");
		xml.append("<a:EntityName>new_my_career</a:EntityName>");
		xml.append("<a:LinkEntities />");
		xml.append("<a:Orders />");
		xml.append("<a:PageInfo>");
		xml.append("<a:Count>0</a:Count>");
		xml.append("<a:PageNumber>0</a:PageNumber>");
		xml.append("<a:PagingCookie i:nil=\"true\" />");
		xml.append("<a:ReturnTotalRecordCount>false</a:ReturnTotalRecordCount>");
		xml.append("</a:PageInfo>");
		xml.append("<a:NoLock>false</a:NoLock>");

		xml.append("</b:value>");
		xml.append("</a:KeyValuePairOfstringanyType>");
		xml.append("</a:Parameters>");
		xml.append("<a:RequestId i:nil=\"true\" />");
		xml.append("<a:RequestName>RetrieveMultiple</a:RequestName>");
		xml.append("</request>");
		xml.append("</Execute>");
		xml.append("</s:Body>");


		//--------response--------
		Document xDoc = CrmExecuteSoap.ExecuteSoapRequest(this.authHeader,xml.toString(), this.url);
		if (xDoc != null){
			DOMSource domSource = new DOMSource(xDoc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.transform(domSource, result);
			String test = writer.toString();
			String x = "a";
		}

		//操作dto
		List<DBA007Dto> list = new ArrayList<DBA007Dto>();

		NodeList nodes = xDoc.getElementsByTagName("b:Entity");
		for(int i = 0; i<nodes.getLength(); i++){
			DBA007Dto dto = new DBA007Dto();
			NodeList attributes = nodes.item(i).getFirstChild().getChildNodes();
			for(int j = 0; j<attributes.getLength();j++){
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_my_careerid")) {
					dto.setNew_my_careerid(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_phase_code")) {
					dto.setNew_phase_code(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_status_code")) {
					dto.setNew_status_code(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_work_phase_a")) {
					dto.setNew_work_phase_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_work_knowledge_a")) {
					dto.setNew_work_knowledge_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_tcd_update_a")) {
					dto.setNew_tcd_update_a(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_self_strength_a")) {
					dto.setNew_self_strength_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_product_a")) {
					dto.setNew_product_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_work_describe_a")) {
					dto.setNew_work_describe_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_market_value_a")) {
					dto.setNew_market_value_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_vision_a")) {
					dto.setNew_vision_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_goal_challenge_a")) {
					dto.setNew_goal_challenge_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_hope_area_a")) {
					dto.setNew_hope_area_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_other_info_a")) {
					dto.setNew_other_info_a(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_interview_date")) {
					dto.setNew_interview_date(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_careerup_content")) {
					dto.setNew_careerup_content(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_careerup_select")) {
					dto.setNew_careerup_select(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_rt_2")) {
					dto.setNew_rt_2(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_rt_plan")) {
					dto.setNew_rt_plan(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_rt_select")) {
					dto.setNew_rt_select(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_effort_plan")) {
					dto.setNew_effort_plan(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_effort_other_plan")) {
					dto.setNew_effort_other_plan(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_effort_status")) {
					dto.setNew_effort_status(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_next_date")) {
					dto.setNew_next_date(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_next_follow")) {
					dto.setNew_next_follow(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_ec_evaluation_date")) {
					dto.setNew_ec_evaluation_date(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_ec_evaluation_opt")) {
					dto.setNew_ec_evaluation_opt(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_ec_evaluation_reason")) {
					dto.setNew_ec_evaluation_reason(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_ec_evaluation_other_opt")) {
					dto.setNew_ec_evaluation_other_opt(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_ec_evaluation_other_reason")) {
					dto.setNew_ec_evaluation_other_reason(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_taika_select")) {
					dto.setNew_taika_select(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_taika_content")) {
					dto.setNew_taika_content(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_check_independence")) {
					dto.setNew_check_independence(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_independence_1")) {
					dto.setNew_independence_1(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_independence_2")) {
					dto.setNew_independence_2(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_independence_3")) {
					dto.setNew_independence_3(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_independence_4")) {
					dto.setNew_independence_4(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_independence_5")) {
					dto.setNew_independence_5(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_independence_6")) {
					dto.setNew_independence_6(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_check_support")) {
					dto.setNew_check_support(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_support_1")) {
					dto.setNew_support_1(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_support_2")) {
					dto.setNew_support_2(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_support_3")) {
					dto.setNew_support_3(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_support_4")) {
					dto.setNew_support_4(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_support_5")) {
					dto.setNew_support_5(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_support_6")) {
					dto.setNew_support_6(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_web_check")) {
					dto.setNew_web_check(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new__human_check")) {
					dto.setNew_human_check(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_salary_remark")) {
					dto.setNew_salary_remark(attributes.item(j).getLastChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_interviewer1")) {
					dto.setNew_interviewer1(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
				if ((attributes.item(j).getFirstChild().getTextContent()).equals("new_interviewer2")) {
					dto.setNew_interviewer2(attributes.item(j).getLastChild().getFirstChild().getTextContent());
					continue;
				}
			}
			list.add(dto);
		}

		return list;
	}

	//MyCareerレコード作成
	private int MyCareerCrtRcd(DBA001Dto rcd){

		String sql = "INSERT INTO GJFT_CARPLA"
				+ "(APPLY_NO, SHAINCD, PHASE_CODE, STATUS_CODE,IS_UPDATED,CRM_GUID) " + "VALUES"
				+ "('" + rcd.getNew_apply_no() + "',"//申請番号
				+ "'" + rcd.getNew_shaindcd() + "',"//社員コード
				+ "'1',"//フェーズコード
				+ "'1',"//ステータスコード
				+ "'1',"//連携済フラグ
				+"'"+rcd.getNew_my_careerid() + "')";//

		OracleDao dao = new OracleDao();
		return dao.executeUpdate(sql);
	}

	//MyCareer連携レコード抽出
	private List<DBA004Dto> MyCareerGetRcd(){
		String sql = "SELECT "
					+ "CRM_GUID"
					+ ",PHASE_CODE"
					+ ",STATUS_CODE"
					+ ",TO_CHAR(SHIN_RPT_DATE, 'yyyy-MM-dd') AS SHIN_RPT_DATE"
					+ ",SHIN_WORK_PHASE"
					+ ",SHIN_WORK_KNOWLEDGE"
					+ ",SHIN_TCD_UPDATE"
					+ ",SHIN_SELF_STRENGTH"
					+ ",SHIN_PRODUCT"
					+ ",SHIN_WORK_DESCRIBE"
					+ ",SHIN_MARKET_VALUE1"
					+ ",SHIN_MARKET_VALUE2"
					+ ",SHIN_MARKET_VALUE3"
					+ ",SHIN_VISION"
					+ ",SHIN_GOAL_CHALLENGE"
					+ ",SHIN_HOPE_AREA"
					+ ",SHIN_OTHER_INFO"
					+ ",TO_CHAR(HYOU_RPT_DATE, 'yyyy-MM-dd') AS HYOU_RPT_DATE"
					+ ",HYOU_SELF_EVALUATION_EFFORT"
					+ " FROM GJFT_CARPLA"
					+ " WHERE PHASE_CODE IN('1','3')"
					+ " AND STATUS_CODE = '2'"
					+ " AND IS_UPDATED = '0'";

		OracleDao dao = new OracleDao();
		return dao.executeQuery(sql);
	}

	//MyCareer連携済更新
	private int MyCareerIsUpdate(DBA004Dto rcd){

		String sql = "UPDATE GJFT_CARPLA SET"
				+ " IS_UPDATED = '" + rcd.getIS_UPDATED() + "'"
				+ " WHERE CRM_GUID='" + rcd.getCRM_GUID() + "'";

		OracleDao dao = new OracleDao();
		return dao.executeUpdate(sql);
	}

	//MyCareer更新データを連携する　※
	private void MyCareerUpdate(DBA007Dto rcd){

		String status_code = rcd.getNew_status_code();
		String phase_code = rcd.getNew_phase_code();
		String sql = "";

		if("3".equals(status_code) || "3".equals(phase_code)){
		//未承認の場合、フェーズおよびステータスのみを更新する
		//または評価申告依頼の場合
			sql = "UPDATE GJFT_CARPLA SET"
					+ " PHASE_CODE = " + rcd.getNew_phase_code() + ","
					+ " STATUS_CODE = " + rcd.getNew_status_code()
					+ " WHERE CRM_GUID='" + rcd.getNew_my_careerid() +"'";
		}else if("4".equals(status_code)){
		//承認済の場合、全データを連携する
			sql = "UPDATE GJFT_CARPLA SET"
				+ " PHASE_CODE = " + rcd.getNew_phase_code() + ","
				+ " STATUS_CODE = " + rcd.getNew_status_code() + ","
				+ " SHAF_WORK_PHASE = " + rcd.getNew_work_phase_a() + ","
				+ " SHAF_WORK_KNOWLEDGE = " + rcd.getNew_work_knowledge_a() + ","
				+ " SHAF_TCD_UPDATE = " + rcd.getNew_tcd_update_a() + ","
				+ " SHAF_SELF_STRENGTH = " + rcd.getNew_self_strength_a() + ","
				+ " SHAF_PRODUCT = " + rcd.getNew_product_a() + ","
				+ " SHAF_WORK_DESCRIBE = " + rcd.getNew_work_describe_a() + ","
				+ " SHAF_MARKET_VALUE = '" + rcd.getNew_market_value_a() + "',"
				+ " SHAF_VISION = " + rcd.getNew_vision_a() + ","
				+ " SHAF_GOAL_CHALLENGE = " + rcd.getNew_goal_challenge_a() + ","
				+ " SHAF_HOPE_AREA = " + rcd.getNew_hope_area_a() + ","
				+ " SHAF_OTHER_INFO = " + rcd.getNew_other_info_a() + ","
				+ " MOKU_DATE = TO_DATE(" + rcd.getNew_interview_date() + ",'YYYYMMDD'),"
				+ " MOKU_INTERVIEWER = " + rcd.getNew_interviewer1() + ","
				+ " MOKU_CAREERUP_CONTENT = " + rcd.getNew_careerup_content() + ","
				+ " MOKU_CAREERUP_SELECT = " + rcd.getNew_careerup_select() + ","
				+ " MOKU_RT_2 = " + rcd.getNew_rt_2() + ","
				+ " MOKU_RT_PLAN = " + rcd.getNew_rt_plan() + ","
				+ " MOKU_RT_SELECT = " + rcd.getNew_rt_select() + ","
				+ " MOKU_EFFORT_PLAN = " + rcd.getNew_effort_plan() + ","
				+ " MOKU_EFFORT_OTHER_PLAN = " + rcd.getNew_effort_other_plan() + ","
				+ " MOKU_EFFORT_STATUS = " + rcd.getNew_effort_status() + ","
				+ " MOKU_NEXT_DATE = TO_DATE(" + rcd.getNew_next_date() + ",'YYYYMMDD'),"
				+ " MOKU_NEXT_FOLLOW = " + rcd.getNew_next_follow() + ","
				+ " HYOU_EC_EVALUATION_DATE = TO_DATE(" + rcd.getNew_ec_evaluation_date() + ",'YYYYMMDD'),"
				+ " HYOU_INTERVIEWER = " + rcd.getNew_interviewer2() + ","
				+ " HYOU_EC_EVALUATION_OPT = " + rcd.getNew_ec_evaluation_opt() + ","
				+ " HYOU_EC_EVALUATION_RSN = " + rcd.getNew_ec_evaluation_reason() + ","
				+ " HYOU_EC_EVALUATION_OTHER_OPT = " + rcd.getNew_ec_evaluation_other_opt() + ","
				+ " HYOU_EC_EVALUATION_OTHER_RSN = " + rcd.getNew_ec_evaluation_other_reason() + ","
				+ " SHOG_TAIKA_SELECT = " + rcd.getNew_taika_select() + ","
				+ " SHOG_TAIKA_CONTENT = " + rcd.getNew_taika_content() + ","
				+ " SHOG_CHECK_INDEPENDENCE = " + rcd.getNew_check_independence() + ","
				+ " SHOG_INDEPENDENCE_1 = " + rcd.getNew_independence_1() + ","
				+ " SHOG_INDEPENDENCE_2 = " + rcd.getNew_independence_2() + ","
				+ " SHOG_INDEPENDENCE_3 = " + rcd.getNew_independence_3() + ","
				+ " SHOG_INDEPENDENCE_4 = " + rcd.getNew_independence_4() + ","
				+ " SHOG_INDEPENDENCE_5 = " + rcd.getNew_independence_5() + ","
				+ " SHOG_INDEPENDENCE_6 = " + rcd.getNew_independence_6() + ","
				+ " SHOG_CHECK_SUPPORT = " + rcd.getNew_check_support() + ","
				+ " SHOG_SUPPORT_1 = " + rcd.getNew_support_1() + ","
				+ " SHOG_SUPPORT_2 = " + rcd.getNew_support_2() + ","
				+ " SHOG_SUPPORT_3 = " + rcd.getNew_support_3() + ","
				+ " SHOG_SUPPORT_4 = " + rcd.getNew_support_4() + ","
				+ " SHOG_SUPPORT_5 = " + rcd.getNew_support_5() + ","
				+ " SHOG_SUPPORT_6 = " + rcd.getNew_support_6() + ","
				+ " SHOG_WEB_CHECK = " + rcd.getNew_web_check() + ","
				+ " SHOG_HUMAN_CHECK = " + rcd.getNew_human_check() + ","
				+ " SHOG_SALARY_REMARK = " + rcd.getNew_salary_remark()
				+ " WHERE CRM_GUID='" + rcd.getNew_my_careerid() +"'";
		}else{
			return;
		}

		OracleDao dao = new OracleDao();
		dao.executeUpdate(sql);
	}

	public static String getStackTrace(final Throwable throwable) {
	     final StringWriter sw = new StringWriter();
	     final PrintWriter pw = new PrintWriter(sw, true);
	     throwable.printStackTrace(pw);
	     return sw.getBuffer().toString();
	}

}


