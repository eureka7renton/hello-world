import java.util.Date;

public class NewTestParent {
	public String new_emp_name;
	public Boolean new_sex;
	public Date new_contact_start_date;
	public int new_emp_age;
	public double new_float;
	public String new_multi;
	public CrmOptionSet new_select_cutomized;
	public CrmMoney new_money;
//	public CrmReference new_lookup;

	public String getNew_emp_name() {
		return new_emp_name;
	}
	public void setNew_emp_name(String new_emp_name) {
		this.new_emp_name = new_emp_name;
	}
	public Boolean getNew_sex() {
		return new_sex;
	}
	public void setNew_sex(Boolean new_sex) {
		this.new_sex = new_sex;
	}
	public Date getNew_contact_start_date() {
		return new_contact_start_date;
	}
	public void setNew_contact_start_date(Date new_contact_start_date) {
		this.new_contact_start_date = new_contact_start_date;
	}
	public CrmOptionSet getNew_select_cutomized() {
		return new_select_cutomized;
	}
	public void setNew_select_cutomized(CrmOptionSet new_select_cutomized) {
		this.new_select_cutomized = new_select_cutomized;
	}
	public int getNew_emp_age() {
		return new_emp_age;
	}
	public void setNew_emp_age(int new_emp_age) {
		this.new_emp_age = new_emp_age;
	}

}
