import java.util.Date;

public class CrmAuthenticationHeader {
	String Header;
	Date Expires;
}
