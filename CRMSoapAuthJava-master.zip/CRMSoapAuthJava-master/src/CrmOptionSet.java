
public class CrmOptionSet {
	public CrmOptionSet(String value) {
		super();
		this.value = value;
	}
	private String value;

	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}


}
