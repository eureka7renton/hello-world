import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dto.DBA004Dto;

public class OracleDao {

    private Statement stmt = null;

    private  ResultSet rs = null;

    private Connection conn = null;

    public OracleDao(){
        this.getConnection();
    }

    private void getConnection(){
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
            String url="jdbc:oracle:thin:@192.168.11.230:1521:mgss2dev"; //
            String user="kojinf";
            String password="kojinf";
            conn= DriverManager.getConnection(url,user,password);
        }catch (Exception e) {
            //System.out.println(e);
        }
    }

    private void close(Connection conn , Statement stmt, ResultSet rs){
        try{
            if(rs != null){
                rs.close();
                rs = null ;
            }
            if(stmt != null){
                stmt.close();
                stmt = null ;
            }
            if(conn != null){
                conn.close();
                conn = null;
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }


    public List executeQuery(String sql) {

    	List<DBA004Dto> list = new ArrayList<DBA004Dto>();
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
            	//TBD
            	DBA004Dto dto = new DBA004Dto();
            	dto.setCRM_GUID(rs.getString("CRM_GUID"));
            	dto.setPHASE_CODE(rs.getString("PHASE_CODE"));
            	dto.setSTATUS_CODE(rs.getString("STATUS_CODE"));
            	dto.setSHIN_RPT_DATE(rs.getString("SHIN_RPT_DATE"));
            	dto.setSHIN_WORK_PHASE(rs.getString("SHIN_WORK_PHASE"));
            	dto.setSHIN_WORK_KNOWLEDGE(rs.getString("SHIN_WORK_KNOWLEDGE"));
            	dto.setSHIN_TCD_UPDATE(rs.getString("SHIN_TCD_UPDATE"));
            	dto.setSHIN_SELF_STRENGTH(rs.getString("SHIN_SELF_STRENGTH"));
            	dto.setSHIN_PRODUCT(rs.getString("SHIN_PRODUCT"));
            	dto.setSHIN_WORK_DESCRIBE(rs.getString("SHIN_WORK_DESCRIBE"));
            	dto.setSHIN_MARKET_VALUE(rs.getString("SHIN_MARKET_VALUE1"),rs.getString("SHIN_MARKET_VALUE2"),rs.getString("SHIN_MARKET_VALUE3"));
            	dto.setSHIN_VISION(rs.getString("SHIN_VISION"));
            	dto.setSHIN_GOAL_CHALLENGE(rs.getString("SHIN_GOAL_CHALLENGE"));
            	dto.setSHIN_HOPE_AREA(rs.getString("SHIN_HOPE_AREA"));
            	dto.setSHIN_OTHER_INFO(rs.getString("SHIN_OTHER_INFO"));
            	dto.setHYOU_RPT_DATE(rs.getString("HYOU_RPT_DATE"));
            	dto.setHYOU_SELF_EVALUATION_EFFORT(rs.getString("HYOU_SELF_EVALUATION_EFFORT"));

            	list.add(dto);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            this.close(conn, stmt, rs);
        }
        return list;
    }

    public int executeUpdate(String sql) {
    	int number = 0 ;
        try {
            stmt = conn.createStatement();
            number = stmt.executeUpdate(sql);;
            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            this.close(this.conn, this.stmt, this.rs);
        }
        return number;
    }

}
