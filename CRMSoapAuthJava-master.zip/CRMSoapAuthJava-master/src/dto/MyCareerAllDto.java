package dto;

public class MyCareerAllDto {
	private String CRM_GUID;
	private String APPLY_NO;
	private String SHAINCD;
	public String getCRM_GUID() {
		return CRM_GUID;
	}
	public void setCRM_GUID(String cRM_GUID) {
		CRM_GUID = cRM_GUID;
	}
	public String getAPPLY_NO() {
		return APPLY_NO;
	}
	public void setAPPLY_NO(String aPPLY_NO) {
		APPLY_NO = aPPLY_NO;
	}
	public String getSHAINCD() {
		return SHAINCD;
	}
	public void setSHAINCD(String sHAINCD) {
		SHAINCD = sHAINCD;
	}
}
