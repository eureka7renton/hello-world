package dto;

public class DBA007Dto {

	private String new_my_careerid;//レコードのGuid
	private String new_phase_code;//面談フェーズ
	private String new_status_code;//面談ステータス

	private String new_work_phase_a;//申告後_業務担当フェーズ
	private String new_work_knowledge_a;//申告後_業務概要*
	private String new_tcd_update_a;//申告後_TCDの更新
	private String new_self_strength_a;//申告後_自分の強み*
	private String new_product_a;//申告後_製品*
	private String new_work_describe_a;//申告後_業務内容*
	private String new_market_value_a;//申告後_市場価値
	private String new_vision_a;//申告後_中長期Vision*
	private String new_goal_challenge_a;//申告後_目標課題*
	private String new_hope_area_a;//申告後_希望地域*
	private String new_other_info_a;//申告後_特記事項*

	private String new_interview_date;//目標_面談日
	private String new_interviewer1;
	private String new_careerup_content;//目標_キャリアアップ計画内容*
	private String new_careerup_select;//目標_キャリアアップ計画選択
	private String new_rt_2;//目標_RT対象者
	private String new_rt_plan;//目標_RT実施時期
	private String new_rt_select;//目標_RT区分
	private String new_effort_plan;//目標_キャリアアップの取組み*
	private String new_effort_other_plan;//目標_他評価の目標設定*
	private String new_effort_status;//目標_ステータス
	private String new_next_date;//目標_次回実施予定日
	private String new_next_follow;//目標_次回フォロー内容*

	private String new_interviewer2;
	private String new_ec_evaluation_date;//評価_EC長評価_日付
	private String new_ec_evaluation_opt;//評価_EC長評価_選択
	private String new_ec_evaluation_reason;//評価_EC長評価_理由*
	private String new_ec_evaluation_other_opt;//評価_EC長評価_他項目選択
	private String new_ec_evaluation_other_reason;//評価_EC長評価_他項目理由*

	private String new_taika_select;//処遇_対価要件_選択
	private String new_taika_content;//処遇_対価要件_内容*
	private String new_check_independence;//処遇_自立
	private String new_independence_1;//処遇_自立_予定1
	private String new_independence_2;//処遇_自立_予定2
	private String new_independence_3;//処遇_自立_予定3
	private String new_independence_4;//処遇_自立_予定4
	private String new_independence_5;//処遇_自立_予定5
	private String new_independence_6;//処遇_自立_予定6
	private String new_check_support;//処遇_支え合い
	private String new_support_1;//処遇_支え合い_予定1
	private String new_support_2;//処遇_支え合い_予定2
	private String new_support_3;//処遇_支え合い_予定3
	private String new_support_4;//処遇_支え合い_予定4
	private String new_support_5;//処遇_支え合い_予定5
	private String new_support_6;//処遇_支え合い_予定6
	private String new_web_check;//処遇_人間力基礎WEB研修
	private String new_human_check;//処遇_社内人間力研修
	private String new_salary_remark;//処遇_備考*

	private boolean new_updated = false;//CRM連携済フラグ

	public String getNew_my_careerid() {
		return new_my_careerid;
	}

	public void setNew_my_careerid(String new_my_careerid) {
		this.new_my_careerid = new_my_careerid;
	}

	public String getNew_phase_code() {
		return new_phase_code;
	}

	public void setNew_phase_code(String new_phase_code) {
		this.new_phase_code = new_phase_code;
	}

	public String getNew_status_code() {
		return new_status_code;
	}

	public void setNew_status_code(String new_status_code) {
		this.new_status_code = new_status_code;
	}

	public String getNew_work_phase_a() {
		return new_work_phase_a;
	}

	public void setNew_work_phase_a(String new_work_phase_a) {
		this.new_work_phase_a = new_work_phase_a;
	}

	public String getNew_work_knowledge_a() {
		return strAddSq(new_work_knowledge_a);
	}

	public void setNew_work_knowledge_a(String new_work_knowledge_a) {
		this.new_work_knowledge_a = new_work_knowledge_a;
	}

	public String getNew_tcd_update_a() {
		return new_tcd_update_a;
	}

	public void setNew_tcd_update_a(String new_tcd_update_a) {
		this.new_tcd_update_a = new_tcd_update_a;
	}

	public String getNew_self_strength_a() {
		return strAddSq(new_self_strength_a);
	}

	public void setNew_self_strength_a(String new_self_strength_a) {
		this.new_self_strength_a = new_self_strength_a;
	}

	public String getNew_product_a() {
		return strAddSq(new_product_a);
	}

	public void setNew_product_a(String new_product_a) {
		this.new_product_a = new_product_a;
	}

	public String getNew_work_describe_a() {
		return strAddSq(new_work_describe_a);
	}

	public void setNew_work_describe_a(String new_work_describe_a) {
		this.new_work_describe_a = new_work_describe_a;
	}

	public String getNew_market_value_a() {
		return new_market_value_a;
	}

	public void setNew_market_value_a(String new_market_value_a) {
		this.new_market_value_a = new_market_value_a;
	}

	public String getNew_vision_a() {
		return strAddSq(new_vision_a);
	}

	public void setNew_vision_a(String new_vision_a) {
		this.new_vision_a = new_vision_a;
	}

	public String getNew_goal_challenge_a() {
		return strAddSq(new_goal_challenge_a);
	}

	public void setNew_goal_challenge_a(String new_goal_challenge_a) {
		this.new_goal_challenge_a = new_goal_challenge_a;
	}

	public String getNew_hope_area_a() {
		return strAddSq(new_hope_area_a);
	}

	public void setNew_hope_area_a(String new_hope_area_a) {
		this.new_hope_area_a = new_hope_area_a;
	}

	public String getNew_other_info_a() {
		return strAddSq(new_other_info_a);
	}

	public void setNew_other_info_a(String new_other_info_a) {
		this.new_other_info_a = new_other_info_a;
	}

	public String getNew_interview_date() {
		return dateStrConvert(new_interview_date);
	}

	public void setNew_interview_date(String new_interview_date) {
		this.new_interview_date = new_interview_date;
	}

	public String getNew_careerup_content() {
		return strAddSq(new_careerup_content);
	}

	public void setNew_careerup_content(String new_careerup_content) {
		this.new_careerup_content = new_careerup_content;
	}

	public String getNew_careerup_select() {
		return new_careerup_select;
	}

	public void setNew_careerup_select(String new_careerup_select) {
		this.new_careerup_select = new_careerup_select;
	}

	public String getNew_rt_2() {
		return booleanStrConvert(new_rt_2);
	}

	public void setNew_rt_2(String new_rt_2) {
		this.new_rt_2 = new_rt_2;
	}

	public String getNew_rt_plan() {
		return new_rt_plan;
	}

	public void setNew_rt_plan(String new_rt_plan) {
		this.new_rt_plan = new_rt_plan;
	}

	public String getNew_rt_select() {
		return new_rt_select;
	}

	public void setNew_rt_select(String new_rt_select) {
		this.new_rt_select = new_rt_select;
	}

	public String getNew_effort_plan() {
		return strAddSq(new_effort_plan);
	}

	public void setNew_effort_plan(String new_effort_plan) {
		this.new_effort_plan = new_effort_plan;
	}

	public String getNew_effort_other_plan() {
		return strAddSq(new_effort_other_plan);
	}

	public void setNew_effort_other_plan(String new_effort_other_plan) {
		this.new_effort_other_plan = new_effort_other_plan;
	}

	public String getNew_effort_status() {
		return new_effort_status;
	}

	public void setNew_effort_status(String new_effort_status) {
		this.new_effort_status = new_effort_status;
	}

	public String getNew_next_date() {
		return dateStrConvert(new_next_date);
	}

	public void setNew_next_date(String new_next_date) {
		this.new_next_date = new_next_date;
	}

	public String getNew_next_follow() {
		return strAddSq(new_next_follow);
	}

	public void setNew_next_follow(String new_next_follow) {
		this.new_next_follow = new_next_follow;
	}

	public String getNew_ec_evaluation_date() {
		return dateStrConvert(new_ec_evaluation_date);
	}

	public void setNew_ec_evaluation_date(String new_ec_evaluation_date) {
		this.new_ec_evaluation_date = new_ec_evaluation_date;
	}

	public String getNew_ec_evaluation_opt() {
		return new_ec_evaluation_opt;
	}

	public void setNew_ec_evaluation_opt(String new_ec_evaluation_opt) {
		this.new_ec_evaluation_opt = new_ec_evaluation_opt;
	}

	public String getNew_ec_evaluation_reason() {
		return strAddSq(new_ec_evaluation_reason);
	}

	public void setNew_ec_evaluation_reason(String new_ec_evaluation_reason) {
		this.new_ec_evaluation_reason = new_ec_evaluation_reason;
	}

	public String getNew_ec_evaluation_other_opt() {
		return new_ec_evaluation_other_opt;
	}

	public void setNew_ec_evaluation_other_opt(String new_ec_evaluation_other_opt) {
		this.new_ec_evaluation_other_opt = new_ec_evaluation_other_opt;
	}

	public String getNew_ec_evaluation_other_reason() {
		return strAddSq(new_ec_evaluation_other_reason);
	}

	public void setNew_ec_evaluation_other_reason(
			String new_ec_evaluation_other_reason) {
		this.new_ec_evaluation_other_reason = new_ec_evaluation_other_reason;
	}

	public String getNew_taika_select() {
		return new_taika_select;
	}

	public void setNew_taika_select(String new_taika_select) {
		this.new_taika_select = new_taika_select;
	}

	public String getNew_taika_content() {
		return strAddSq(new_taika_content);
	}

	public void setNew_taika_content(String new_taika_content) {
		this.new_taika_content = new_taika_content;
	}

	public String getNew_check_independence() {
		return new_check_independence;
	}

	public void setNew_check_independence(String new_check_independence) {
		this.new_check_independence = new_check_independence;
	}

	public String getNew_independence_1() {
		return new_independence_1;
	}

	public void setNew_independence_1(String new_independence_1) {
		this.new_independence_1 = new_independence_1;
	}

	public String getNew_independence_2() {
		return new_independence_2;
	}

	public void setNew_independence_2(String new_independence_2) {
		this.new_independence_2 = new_independence_2;
	}

	public String getNew_independence_3() {
		return new_independence_3;
	}

	public void setNew_independence_3(String new_independence_3) {
		this.new_independence_3 = new_independence_3;
	}

	public String getNew_independence_4() {
		return new_independence_4;
	}

	public void setNew_independence_4(String new_independence_4) {
		this.new_independence_4 = new_independence_4;
	}

	public String getNew_independence_5() {
		return new_independence_5;
	}

	public void setNew_independence_5(String new_independence_5) {
		this.new_independence_5 = new_independence_5;
	}

	public String getNew_independence_6() {
		return new_independence_6;
	}

	public void setNew_independence_6(String new_independence_6) {
		this.new_independence_6 = new_independence_6;
	}

	public String getNew_check_support() {
		return new_check_support;
	}

	public void setNew_check_support(String new_check_support) {
		this.new_check_support = new_check_support;
	}

	public String getNew_support_1() {
		return new_support_1;
	}

	public void setNew_support_1(String new_support_1) {
		this.new_support_1 = new_support_1;
	}

	public String getNew_support_2() {
		return new_support_2;
	}

	public void setNew_support_2(String new_support_2) {
		this.new_support_2 = new_support_2;
	}

	public String getNew_support_3() {
		return new_support_3;
	}

	public void setNew_support_3(String new_support_3) {
		this.new_support_3 = new_support_3;
	}

	public String getNew_support_4() {
		return new_support_4;
	}

	public void setNew_support_4(String new_support_4) {
		this.new_support_4 = new_support_4;
	}

	public String getNew_support_5() {
		return new_support_5;
	}

	public void setNew_support_5(String new_support_5) {
		this.new_support_5 = new_support_5;
	}

	public String getNew_support_6() {
		return new_support_6;
	}

	public void setNew_support_6(String new_support_6) {
		this.new_support_6 = new_support_6;
	}

	public String getNew_web_check() {
		return booleanStrConvert(new_web_check);
	}

	public void setNew_web_check(String new_web_check) {
		this.new_web_check = new_web_check;
	}

	public String getNew_salary_remark() {
		return strAddSq(new_salary_remark);
	}

	public void setNew_salary_remark(String new_salary_remark) {
		this.new_salary_remark = new_salary_remark;
	}

	public boolean isNew_updated() {
		return new_updated;
	}

	public void setNew_updated(boolean new_updated) {
		this.new_updated = new_updated;
	}

	//複数行テキストの加工処理　※シングルクォーテーションを追加する
	private String strAddSq(String strInS){
		if(strInS == null || ("").equals(strInS )){
			return null;
		}else{
			return "'"+strInS+"'";
		}
	}

	//日付データの加工処理 2017-07-20T00:00:00->20170720
	private String dateStrConvert(String strInS){
		if(strInS == null || ("").equals(strInS )){
			return null;
		}else{
			return strInS.substring(0, 4)+strInS.substring(5, 7)+strInS.substring(8, 10);
		}
	}

	//booleanデータの加工処理
	private String booleanStrConvert(String strInS){
		if(strInS == null || ("").equals(strInS )){
			return null;
		}else if(strInS.equals("true")){
			return "1";
		}else if(strInS.equals("false")){
			return "0";
		}
		return null;
	}

	public String getNew_human_check() {
		return new_human_check;
	}

	public void setNew_human_check(String new_human_check) {
		this.new_human_check = new_human_check;
	}

	public String getNew_interviewer1() {
		return strAddSq(new_interviewer1);
	}

	public void setNew_interviewer1(String new_interviewer1) {
		this.new_interviewer1 = new_interviewer1;
	}

	public String getNew_interviewer2() {
		return strAddSq(new_interviewer2);
	}

	public void setNew_interviewer2(String new_interviewer2) {
		this.new_interviewer2 = new_interviewer2;
	}
}
