package dto;

public class DBA004Dto {
	private String CRM_GUID;
	private String PHASE_CODE;
	private String STATUS_CODE;
	private String SHIN_RPT_DATE;
	private String SHIN_WORK_PHASE;
	private String SHIN_WORK_KNOWLEDGE;
	private String SHIN_TCD_UPDATE;
	private String SHIN_SELF_STRENGTH;
	private String SHIN_PRODUCT;
	private String SHIN_WORK_DESCRIBE;
	private String SHIN_MARKET_VALUE;
	private String SHIN_VISION;
	private String SHIN_GOAL_CHALLENGE;
	private String SHIN_HOPE_AREA;
	private String SHIN_OTHER_INFO;
	private String HYOU_RPT_DATE;
	private String HYOU_SELF_EVALUATION_EFFORT;
	private String IS_UPDATED;

	public String getCRM_GUID() {
		return CRM_GUID;
	}
	public void setCRM_GUID(String cRM_GUID) {
		CRM_GUID = cRM_GUID;
	}
	public String getPHASE_CODE() {
		return PHASE_CODE;
	}
	public void setPHASE_CODE(String pHASE_CODE) {
		PHASE_CODE = pHASE_CODE;
	}
	public String getSTATUS_CODE() {
		return STATUS_CODE;
	}
	public void setSTATUS_CODE(String sTATUS_CODE) {
		STATUS_CODE = sTATUS_CODE;
	}
	public String getSHIN_RPT_DATE() {
		return SHIN_RPT_DATE;
	}
	public void setSHIN_RPT_DATE(String sHIN_RPT_DATE) {
		SHIN_RPT_DATE = ( sHIN_RPT_DATE != null ? sHIN_RPT_DATE : "" );
	}
	public String getSHIN_WORK_PHASE() {
		return SHIN_WORK_PHASE;
	}
	public void setSHIN_WORK_PHASE(String sHIN_WORK_PHASE) {
		SHIN_WORK_PHASE = sHIN_WORK_PHASE;
	}
	public String getSHIN_WORK_KNOWLEDGE() {
		return SHIN_WORK_KNOWLEDGE;
	}
	public void setSHIN_WORK_KNOWLEDGE(String sHIN_WORK_KNOWLEDGE) {
		SHIN_WORK_KNOWLEDGE = ( sHIN_WORK_KNOWLEDGE != null ? sHIN_WORK_KNOWLEDGE : "" );
	}
	public String getSHIN_TCD_UPDATE() {
		return SHIN_TCD_UPDATE;
	}
	public void setSHIN_TCD_UPDATE(String sHIN_TCD_UPDATE) {
		SHIN_TCD_UPDATE = sHIN_TCD_UPDATE;
	}
	public String getSHIN_SELF_STRENGTH() {
		return SHIN_SELF_STRENGTH;
	}
	public void setSHIN_SELF_STRENGTH(String sHIN_SELF_STRENGTH) {
		SHIN_SELF_STRENGTH = ( sHIN_SELF_STRENGTH != null ? sHIN_SELF_STRENGTH : "" );
	}
	public String getSHIN_PRODUCT() {
		return SHIN_PRODUCT;
	}
	public void setSHIN_PRODUCT(String sHIN_PRODUCT) {
		SHIN_PRODUCT = ( sHIN_PRODUCT != null ? sHIN_PRODUCT : "" );
	}
	public String getSHIN_WORK_DESCRIBE() {
		return SHIN_WORK_DESCRIBE;
	}
	public void setSHIN_WORK_DESCRIBE(String sHIN_WORK_DESCRIBE) {
		SHIN_WORK_DESCRIBE = ( sHIN_WORK_DESCRIBE != null ? sHIN_WORK_DESCRIBE : "" );
	}
	public String getSHIN_MARKET_VALUE() {
		return SHIN_MARKET_VALUE;
	}
	public void setSHIN_MARKET_VALUE(String sHIN_MARKET_VALUE1,String sHIN_MARKET_VALUE2,String sHIN_MARKET_VALUE3) {
		SHIN_MARKET_VALUE = "3年後：" + ( sHIN_MARKET_VALUE1 != null ? sHIN_MARKET_VALUE1 : "" )
				+ "　5年後：" + ( sHIN_MARKET_VALUE2 != null ? sHIN_MARKET_VALUE2 : "" )
				+ "　10年後：" + ( sHIN_MARKET_VALUE3 != null ? sHIN_MARKET_VALUE3 : "" );
	}
	public String getSHIN_VISION() {
		return SHIN_VISION;
	}
	public void setSHIN_VISION(String sHIN_VISION) {
		SHIN_VISION = ( sHIN_VISION != null ? sHIN_VISION : "" );
	}
	public String getSHIN_GOAL_CHALLENGE() {
		return SHIN_GOAL_CHALLENGE;
	}
	public void setSHIN_GOAL_CHALLENGE(String sHIN_GOAL_CHALLENGE) {
		SHIN_GOAL_CHALLENGE = ( sHIN_GOAL_CHALLENGE != null ? sHIN_GOAL_CHALLENGE : "" );
	}
	public String getSHIN_HOPE_AREA() {
		return SHIN_HOPE_AREA;
	}
	public void setSHIN_HOPE_AREA(String sHIN_HOPE_AREA) {
		SHIN_HOPE_AREA = ( sHIN_HOPE_AREA != null ? sHIN_HOPE_AREA : "" );
	}
	public String getSHIN_OTHER_INFO() {
		return SHIN_OTHER_INFO;
	}
	public void setSHIN_OTHER_INFO(String sHIN_OTHER_INFO) {
		SHIN_OTHER_INFO = ( sHIN_OTHER_INFO != null ? sHIN_OTHER_INFO : "" );
	}
	public String getHYOU_RPT_DATE() {
		return HYOU_RPT_DATE;
	}
	public void setHYOU_RPT_DATE(String hYOU_RPT_DATE) {
		HYOU_RPT_DATE = ( hYOU_RPT_DATE != null ? hYOU_RPT_DATE : "" );
	}
	public String getHYOU_SELF_EVALUATION_EFFORT() {
		return HYOU_SELF_EVALUATION_EFFORT;
	}
	public void setHYOU_SELF_EVALUATION_EFFORT(String hYOU_SELF_EVALUATION_EFFORT) {
		HYOU_SELF_EVALUATION_EFFORT = ( hYOU_SELF_EVALUATION_EFFORT != null ? hYOU_SELF_EVALUATION_EFFORT : "" );
	}
	public String getIS_UPDATED() {
		return IS_UPDATED;
	}
	public void setIS_UPDATED(String iS_UPDATED) {
		IS_UPDATED = iS_UPDATED;
	}

}
