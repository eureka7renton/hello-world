package dto;

public class DBA001Dto {

	private String new_apply_no;
	private String new_shaindcd;
	private String new_my_careerid;
	private boolean new_updated = false;

	public String getNew_apply_no() {
		return new_apply_no;
	}
	public void setNew_apply_no(String new_apply_no) {
		this.new_apply_no = new_apply_no;
	}
	public String getNew_shaindcd() {
		return new_shaindcd;
	}
	public void setNew_shaindcd(String new_shaindcd) {
		this.new_shaindcd = new_shaindcd;
	}
	public String getNew_my_careerid() {
		return new_my_careerid;
	}
	public void setNew_my_careerid(String new_my_careerid) {
		this.new_my_careerid = new_my_careerid;
	}
	public boolean isNew_updated() {
		return new_updated;
	}
	public void setNew_updated(boolean new_updated) {
		this.new_updated = new_updated;
	}

}
