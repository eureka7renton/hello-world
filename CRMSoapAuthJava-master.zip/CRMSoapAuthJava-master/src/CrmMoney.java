
public class CrmMoney {
	private int value;

	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public CrmMoney(int value) {
		super();
		this.value = value;
	}


}
